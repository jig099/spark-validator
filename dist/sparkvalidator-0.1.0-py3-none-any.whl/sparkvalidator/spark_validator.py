from sampler import *
from functions import *
from profiler import *

class spark_validator(sampler):

   def __init__(self, sampler):
       self.sampler = sampler()



